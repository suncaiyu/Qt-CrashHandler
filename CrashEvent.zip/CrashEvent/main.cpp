﻿#include "MainWindow.h"
#include <QApplication>
#include <windows.h>
#include <QMessageBox>
#include "msg_box.h"


//void dialog::showBox()
//{

//    MsgBox *msgBox=new MsgBox(1,QStringLiteral("请输入卡口名或路口名"));//1为警告框
//    int nRes=msgBox->exec();
//    msgBox=new MsgBox(2,QStringLiteral("请输入卡口名或路口名"));//2为提示框
//    nRes=msgBox->exec();
//    msgBox=new MsgBox(3,QStringLiteral("确定修改路口名称"));//3为询问框
//    nRes=msgBox->exec();
//    if(nRes==QDialog::Accepted)
//    {
//    //  处理按下确定按钮的语句
//    }
//    else if(nRes==QDialog::Rejected)
//    {
//        //处理按下取消或者关闭按钮的语句
//    }
//}
LONG ApplicationCrashHandler(EXCEPTION_POINTERS *pException){//程式异常捕获
    /*
      ***保存数据代码***
    */
    //这里弹出一个错误对话框并退出程序
    EXCEPTION_RECORD* record = pException->ExceptionRecord;
    QString errCode(QString::number(record->ExceptionCode,16)),errAdr(QString::number((uint)record->ExceptionAddress,16)),errMod;
//    QMessageBox::critical(NULL,QStringLiteral("程式崩溃"),QStringLiteral("<FONT size=4><div><b>对于发生的错误，表示诚挚的歉意</b><br/></div>")+
//                                                QStringLiteral("<div>错误代码：%1</div><div>错误地址：%2</div></FONT>").arg(errCode).arg(errAdr),
//                          QMessageBox::Ok);
    MsgBox *msgBox=new MsgBox(1,QStringLiteral("请输入卡口名或路口名"));
    int nRes=msgBox->exec();
    if(nRes==QDialog::Accepted)
          {
          //  处理按下确定按钮的语句
          }
          else if(nRes==QDialog::Rejected)
          {
              //处理按下取消或者关闭按钮的语句
          }
    return EXCEPTION_EXECUTE_HANDLER;
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    SetUnhandledExceptionFilter((LPTOP_LEVEL_EXCEPTION_FILTER)ApplicationCrashHandler);//注冊异常捕获函数
    MainWindow w;
    w.show();
    return a.exec();
}

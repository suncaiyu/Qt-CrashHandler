﻿#include "MainWindow.h"
#include "ui_MainWindow.h"
#include <QLabel>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
      , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QLabel *l;
    l->show();
}

MainWindow::~MainWindow()
{
    delete ui;
}

